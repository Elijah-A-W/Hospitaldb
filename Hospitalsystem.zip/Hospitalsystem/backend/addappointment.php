<?php

    include_once 'main.php';
    $my_var = new main();
    
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $app_id = $_POST['id'];
        $name = $_POST['name'];
        $doc = $_POST['doc'];
        $date= $_POST['date'];
        $time = $_POST['time'];
        $email= $_POST['email'];
        $num = $_POST['num'];
        $mess = $_POST['message'];
        $apptmnt = $_POST['status'];

        $my_var->Login($name, $age, $weight, $id, $birth, $gender, $address, $phone);

    }


?>