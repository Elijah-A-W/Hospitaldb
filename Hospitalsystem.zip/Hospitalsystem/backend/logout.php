<?php
    session_start();
    $_SESSION = array();
    
    session_destroy();
    session_abort();

    return header('Location: ../index.php');
    exit();

?>