<?php

    include_once 'main.php';
    $my_var = new main();
    
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $name = $_POST['name'];
        $susdisease = $_POST['suspd_disease'];
        $confdisease = $_POST['con_disease'];
        $disease = $_POST['disease'];
        $date= $_POST['date'];

        $my_var->Login($name, $susdisease , $confdisease, $disease, $date);

    }


?>