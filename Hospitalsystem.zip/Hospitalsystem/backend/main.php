<?php
class main{

    private $connection;

    function __construct(){

        // define('DB_SERVER',"USERNAME');
        $this->connection = mysqli_connect('localhost','root', '', 'thedb');
        if( $this->connection === false){
            echo "connection error";
        } else {
            // echo "connection established";
        }
    }

    function regester($username, $password, $email, $phone){

        $encrypted_pswd = md5($password);

        $sql_regester = "INSERT INTO users(`full_name`, `email`, `phonenumber`, `password`) VALUES('$username', '$email', '$phone', '$encrypted_pswd')";

        if(mysqli_query($this->connection,  $sql_regester)){
            header('location: ../index.php');
        }else{
            echo "regerster error";
        }
    }

    function Login($email, $password){
        $encrypted_pswd = md5($password);
        $login_query = "SELECT * FROM users where email='$email' AND password='$encrypted_pswd'";



        // querry the db
        $Authorize = mysqli_query($this->connection, $login_query);
        $new_auth = mysqli_fetch_assoc($Authorize);



        // validations before authorisng
        if($new_auth['id']){
           session_start();

           $_SESSION["Loggedin"] = true;
           $_SESSION["id"] = $new_auth['id'];
           $_SESSION["name"] = $new_auth['full_name'];
           $_SESSION["email"] = $new_auth['email'];
           $_SESSION["role"] = $new_auth['role'];

           header('Location: ../dashboard.php');

        }else{
            echo"error";
        }
    }

    function addPatient(){



        $new_auth = mysqli_fetch_assoc($Authorize);





        $_SESSION["id"] = $new_auth['id'];
        $_SESSION["name"] = $new_auth['full_name'];
        $_SESSION["email"] = $new_auth['email'];
        $_SESSION["role"] = $new_auth['role'];



    }

}
?>