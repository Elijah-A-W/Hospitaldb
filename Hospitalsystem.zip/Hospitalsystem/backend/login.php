<?php

    include_once 'main.php';
    $my_var = new main();
    
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $email = $_POST['email'];
        $psswd = $_POST['password'];

        $my_var->Login($email, $psswd);

    }


?>