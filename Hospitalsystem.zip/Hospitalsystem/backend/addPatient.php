<?php

    include_once 'main.php';
    $my_var = new main();
    
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $name = $_POST['name'];
        $age = $_POST['age'];
        $weight = $_POST['weight'];
        $id = $_POST['id'];
        $birth = $_POST['birth'];
        $gender = $_POST['gender'];
        $address = $_POST['address'];
        $phone = $_POST['phone'];

        $my_var->Login($name, $age, $weight, $id, $birth, $gender, $address, $phone);

    }


?>