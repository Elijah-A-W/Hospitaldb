<?php

include_once 'main.php';
$my_var = new main();

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $user = $_POST['username'];
    $email = $_POST['email'];
    $psswd = $_POST['password'];
    $number = $_POST['num'];

    $my_var->regester($user, $psswd, $email, $number);

}


?>