<div class="sidebar" id="sidebar">
            <div class="sidebar-inner slimscroll">
                <div id="sidebar-menu" class="sidebar-menu">
                    <ul>
                        <li class="menu-title">Main</li>

                        <li <?php if($_SESSION['page'] == 'dash'){?> class="active" <?php }?>>
                            <a href="dashboard.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
                        </li>

                        <?php 
                            if($_SESSION["role"] == 'admin'){
                        ?>

                        <li <?php if($_SESSION['page'] == 'docs'){?> class="active" <?php }?>>
                            <a href="doctors.php"><i class="fa fa-user-md"></i> <span>Doctors</span></a>
                         </li>
                        
                         <li>
                            <a href="patients.php"><i class="fa fa-wheelchair"></i> <span>Patients</span></a>
                        </li>

                        <li>
                            <a href="Laboratory.php"><i class="fa fa-calendar"></i> <span>Laboratory</span></a>
                        </li>
                        
                        <li>
                            <a href="medicine.php"><i class="fa fa-hospital-o"></i> <span>Medicine</span></a>
                        </li>

                        <?php
                        } else if($_SESSION["role"] == 'drug') {
                            ?>

                            <li <?php if($_SESSION['page'] == 'Drug'){?> class="active" <?php }?>>
                                <a href="DrugAuthority.php"><i class="fa fa-cog"></i> <span>DrugAuthority</span></a>
                            </li>

                        <?php
                        } else if($_SESSION["role"] == 'user') {
                            ?>

                            <li <?php if($_SESSION['page'] == 'docs'){?> class="active" <?php }?>>
                                <a href="doctors.php"><i class="fa fa-user-md"></i> <span>Doctors</span></a>
                            </li>
                            
                            <li>
                                <a href="patients.php"><i class="fa fa-wheelchair"></i> <span>Patients</span></a>
                            </li>

                            <li>
                                <a href="appointments.php"><i class="fa fa-wheelchair"></i> <span>Appointment</span></a>
                            </li>

                        <?php
                        } else if($_SESSION["role"] == 'doc') {
                            ?>

                            <li <?php if($_SESSION['page'] == 'docs'){?> class="active" <?php }?>>
                                <a href="Laboratory.php"><i class="fa fa-calendar"></i> <span>Laboratory</span></a>
                            </li>
                            
                                 
                            <li>
                                 <a href="medicine.php"><i class="fa fa-hospital-o"></i> <span>Medicine</span></a>
                            </li>

                            <li>
                                <a href="appointments.php"><i class="fa fa-wheelchair"></i> <span>Appointment</span></a>
                            </li>

                            

                            <?php
                         } 
                        
                                              
    
                  ?>
                    </li>
                    </ul>
                </div>
            </div>
        </div>