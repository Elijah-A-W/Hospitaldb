<?php 
    session_start();
    if(!isset($_SESSION["Loggedin"]) || $_SESSION["Loggedin"]  !== true){
        header("Location: index.php");
    }
    include_once 'includes/head.php';
    $_SESSION['page'] = 'Drug';
    
?>
    <div class="main-wrapper">

    <?php include_once 'includes/header.php' ?>
    <?php include_once 'includes/sidenav.php' ?>

        <div class="page-wrapper">
                <div class="content">
                        <div class="row">
                            <div class="col-sm-4 col-3">
                                <h4 class="page-title">Disease Analysis</h4>
                            </div>
                            <div class="col-sm-8 col-9 text-right m-b-20">
                                <a href="add-patient.html" class="btn btn btn-primary btn-rounded float-right"><i class="fa fa-plus"></i></a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="table-responsive">
                                    <table class="table table-border table-striped custom-table datatable mb-0">
                                        <thead>
                                            <tr>
                                                <th>Hospital Name</th>
                                                <th>Disease Name</th>
                                                <th>Disease ID</th>
                                                <th>Disease Count</th>
                                              
                                                <th>Date of Issue</th>
                                                <th>Address</th>
                                                <th>Contact</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Odong Martin</td>
                                                <td>35</td>
                                                <td>Bweyogerer</td>
                                                <td>(207) 808 8863</td>
                                                <td>jenniferrobinson@example.com</td>
                                                <td>adcc</td>
                                                <td>fcc</td>
                                                <td class="text-right">
                                                    <div class="dropdown dropdown-action">
                                                        <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                                                        <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="Recommend.php"><i class="fa fa-pencil m-r-5"></i> Recommend</a>
                                                            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_patient"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>                                       
                                        </tbody>
                                    </table>
                            
                            <br>
                            <br>
                            <div class="">
                             <h2>Medicine Analysis</h2>
                             <table class="table table-striped custom-table mb-0 datatable">
                                <thead>
                                    <tr>
                                        <th>Hospital Name</th>
                                        <th>Medicine Name</th>
                                        <th>Status</th>
                                        <th>Address</th>
                                        <th>Date</th>
                                        <th class="text-right">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr style="overflow: hidden">
                                        <td>KIH</td>
                                        <td>DOEX</td>
                                        <td><span class="custom-badge status-green">Available</span></td>
                                        <td>KAMOCHA</td>
                                        <td>04/9/19</td>
                                        <td class="text-right">
                                                    <div class="dropdown dropdown-action">
                                                        <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                                                        <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="Recommend.php"><i class="fa fa-pencil m-r-5"></i> Recommend</a>
                                                            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_patient"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
                                                        </div>
                                                    </div>
                                        </td>
                                    </tr>                                   
                                </tbody>
                            </table>
                            </div> 
                                </div>
                            </div>
                        </div>
                    </div>
        </div>
            
          
            <div class="notification-box">
                <div class="msg-sidebar notifications msg-noti">
                    <div class="topnav-dropdown-header">
                        <span>Messages</span>
                    </div>
                    <div class="drop-scroll msg-list-scroll" id="msg_list">
                        <ul class="list-box">
                           

                        </ul>
                    </div>
                    <div class="topnav-dropdown-footer">
                        <a href="chat.html">See all messages</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="sidebar-overlay" data-reff=""></div>
        <script src="assets/js/jquery-3.2.1.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/select2.min.js"></script>
        <script src="assets/js/app.js"></script>
</body>


<!-- settings23:11-->

</html>